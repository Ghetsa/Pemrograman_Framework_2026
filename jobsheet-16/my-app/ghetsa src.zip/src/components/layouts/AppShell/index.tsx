import Navbar from "../navbar";
import Footer from "../footer";
import { useRouter } from "next/router";

const disableNavbar = ['/auth/login', '/auth/register', "/404"];

type AppShellProps = {
  children: React.ReactNode;
}

const AppShell = (props: AppShellProps) => {
  const { children } = props;
  const { pathname } = useRouter();
  return (
    <main>
      {!disableNavbar.includes(pathname) && <Navbar />}
      {children}
      {/* <br /> */}
      {!disableNavbar.includes(pathname) && <Footer />}
    </main>

  );
};

export default AppShell;

